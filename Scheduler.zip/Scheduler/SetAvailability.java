
import java.io.PrintWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
public class SetAvailability
{
    public static String SetAvailability() throws FileNotFoundException
    {
        //Variables declared below.
        String name;
        String newAvailability = "";
        String daysAvailable;
        String hrsAvailable;
        int nSelection2 = 0;
        final int SENTINEL = 10;
        Scanner keyboardInput = new Scanner(System.in);

        //Employee name will also be the file extension.
        System.out.println("Enter Employee Name: ");
        name = keyboardInput.nextLine();
        System.out.println();
        //file is created below.
        try {
            File file = new File(name + ".txt");

            if(!file.exists()) {
                file.createNewFile();	
            }
            System.out.println("New Employee Availability Created");
            System.out.println();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //scanner variable to send info to file down below.
        PrintWriter output = new PrintWriter(name + ".txt");

        System.out.println("READ THE INSTRUCTIONS CAREFULLY!");
        //Prompt User with day menu to set availability.
        System.out.println("Select Day by Number:");
        System.out.println("---------------------");
        System.out.println("1. Monday......");
        System.out.println("2. Tuesday.....");
        System.out.println("3. Wednesday...");
        System.out.println("4. Thursday....");
        System.out.println("5. Friday......");
        System.out.println("6. Saturday....");
        System.out.println("7. Sunday......");
        System.out.println();
        System.out.println("Enter \"10\" When DONE");
        System.out.println();
        System.out.println("Enter Hours Available ex.12am-11pm ");

        while (nSelection2 != SENTINEL){
            try{
                System.out.println("Select Day To Set Availability: ");
                nSelection2 = keyboardInput.nextInt();
                hrsAvailable = keyboardInput.nextLine();
                if (nSelection2 ==1 ){  
                    System.out.println();
                    System.out.print("Enter Hours Available on Monday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Monday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==2 ){
                    System.out.println();
                    System.out.print("Enter Hours Available on Tuesday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Tuesday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==3){
                    System.out.println();
                    System.out.print("Enter Hours Available on Wednesday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Wednesday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==4){
                    System.out.println();
                    System.out.print("Enter Hours Available on Thursday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Thursday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==5){
                    System.out.println();
                    System.out.print("Enter Hours Available on Friday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Friday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==6){
                    System.out.println();
                    System.out.print("Enter Hours Available on Saturday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Saturday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 == 7){
                    System.out.println();
                    System.out.print("Enter Hours Available on Sunday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Sunday " + hrsAvailable );
                    output.printf("%n");

                }else if(nSelection2 == SENTINEL){
                    output.close();
                }
            }
            catch(InputMismatchException e){
                System.out.println("Invalid Entry try again!");
                hrsAvailable = keyboardInput.nextLine();
                if (nSelection2 ==1 ){  
                    System.out.println();
                    System.out.print("Enter Hours Available on Monday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Monday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==2 ){
                    System.out.println();
                    System.out.print("Enter Hours Available on Tuesday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Tuesday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==3){
                    System.out.println();
                    System.out.print("Enter Hours Available on Wednesday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Wednesday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==4){
                    System.out.println();
                    System.out.print("Enter Hours Available on Thursday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Thursday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==5){
                    System.out.println();
                    System.out.print("Enter Hours Available on Friday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Friday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 ==6){
                    System.out.println();
                    System.out.print("Enter Hours Available on Saturday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Saturday " + hrsAvailable );
                    output.printf("%n");

                }
                else if (nSelection2 == 7){
                    System.out.println();
                    System.out.print("Enter Hours Available on Sunday: ");
                    hrsAvailable += keyboardInput.nextLine();
                    output.printf("Sunday " + hrsAvailable );
                    output.printf("%n");

                }else if(nSelection2 == SENTINEL){
                    output.close();
                }
            }
        }
        return newAvailability;
    }
}