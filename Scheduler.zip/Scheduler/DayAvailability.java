import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;
public class DayAvailability
{
    public static String DayAvailability()throws FileNotFoundException
    {

        // Variables Declared Below.
        String usrInput = "";
        String day = "";
        int nSelection1 = 0;
        final int SENTINEL = 10;
        Scanner keyboardInput = new Scanner (System.in);
        PrintWriter output = new PrintWriter(day + ".txt");
        String dayAvail = "";      
        //Prompt Day Menu.
        System.out.println("Select Day by Number to See Day Availability:");
        System.out.println("---------------------");
        System.out.println("1. Monday......");
        System.out.println("2. Tuesday.....");
        System.out.println("3. Wednesday...");
        System.out.println("4. Thursday....");
        System.out.println("5. Friday......");
        System.out.println("6. Saturday....");
        System.out.println("7. Sunday......");
        System.out.println("---------------------");
        System.out.println("Enter \"10\" When DONE");

        while (nSelection1 != SENTINEL){
            System.out.println();
            System.out.print("Enter a New Day or End Program: ");
            usrInput = keyboardInput.next();
            try {
                nSelection1 = Integer.parseInt(usrInput);
                if (nSelection1 ==1 ){  
                    day = "Monday";
                }
                else if (nSelection1 ==2 ){
                    day = "Tuesday";
                }
                else if (nSelection1 ==3){
                    day = "Wednesday";
                }
                else if (nSelection1 ==4){
                    day = "Thursday";
                }
                else if (nSelection1 ==5){
                    day = "Friday";
                }
                else if (nSelection1 ==6){
                    day = "Saturday";
                }
                else if (nSelection1 == 7){
                    day = "Sunday";
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("Invalid selection! Try Again.");
            }

        }

        File file =new File("GetNames.txt");
        Scanner input = null;
        try {
            input = new Scanner(file);
            while(input.hasNext())
            {
                String line=input.nextLine();
                if(line.contains(".txt")){
                    System.out.println(line);
                }
                if (line.contains(day)){
                    System.out.println(line);
                    System.out.println();
                }
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return dayAvail;
        //end while user did not enter 10
    }
}

