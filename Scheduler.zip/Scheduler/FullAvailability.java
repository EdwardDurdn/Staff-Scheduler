
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.InputMismatchException;
public class FullAvailability{        
    public static String FullAvailability() throws IOException{
        //Class Variables.
        Scanner userInput = new Scanner(System.in);
        int nSelection3 = 0;
        String strLine = "";
        //Variable to send output to folder below.
        PrintWriter output = new PrintWriter("GetNames.txt");
        //Reading input from file below.
        File directory = new File("Available Today");
        do{
            System.out.println("------Availability Folder-------");
            output.println("------Availability Folder-------");           
            File[] contents = directory.listFiles();
            for ( File f : contents) {
                System.out.println(f.getPath());
                output.println(f.getPath());
                try(BufferedReader br  = new BufferedReader(new FileReader(f))){
                    // Read lines from the file, returns null when end of stream 
                    // is reached
                    while((strLine = br.readLine()) != null){
                        System.out.println(strLine);
                        output.println(strLine);
                    }
                }
            }
            System.out.println("--------------------------------");
            output.println("--------------------------------");
            output.close();
            System.out.println("End Of File");
            System.out.println();
            System.out.println("To Exit Enter \"10\"");
            //Ending loop option.            
            try {
                nSelection3 = userInput.nextInt();
            }catch(InputMismatchException e)
            {
                System.out.println("Invalid Entry Try Again");
                nSelection3 = userInput.nextInt();
            }
            
        }while(nSelection3 != 10);
        return strLine;
    }

}