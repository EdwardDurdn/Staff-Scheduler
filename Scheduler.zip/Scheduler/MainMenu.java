        /*System.out.println("Programmer: Benjamin Lagunas");      
        System.out.println("Java Programming");
        System.out.println();
        System.out.println("Date Created December 24, 2019;");
        System.out.println("########################################");
        */
import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;              //for layout managers and more
import java.awt.event.*;        //for action events

import java.net.URL;
import java.io.IOException;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
public class MainMenu
{

    public static void main (String [] args) throws IOException
    {

        //Variables declared below.
        Scanner keyboardInput = new Scanner(System.in);
        String userInput;
        final String PASSWORD = "Pass123";
        //Prompt Password Verification.
        System.out.println("Welcome To Staff Scheduler");
        System.out.println();
        System.out.println("Please enter password: ");
        System.out.print("Password:Pass123");
        userInput = keyboardInput.nextLine();
        while(!PASSWORD.equals(userInput))
        {
            System.out.println("Incorrect password");
            System.out.println("Please re-enter password: ");
            userInput=keyboardInput.nextLine();
        }
        System.out.println("Access granted");
        System.out.println();
        DayAvailability dayAvailability = new DayAvailability();
        FullAvailability fullAvailability = new FullAvailability();
        SetAvailability setAvailability = new SetAvailability();

        //variables for whileloop.
        String input ="";
        int nSelection = 0;
        final int END = 10;

        //Prompt Main Menu.
        System.out.println("Please Select a Number From Menu Below." );
        System.out.println("----------------------------------------");
        System.out.println("1. Day Availability..........");
        System.out.println("2. Set New Availability......");
        System.out.println("3. Full Availability........");
        System.out.println("4. Create Schedule..........");
        System.out.println();
        System.out.println("To End Program Enter \"10\" ");

        while (nSelection !=END){
            System.out.println("Select a number.");
            input = keyboardInput.next();
            try {
                nSelection = Integer.parseInt(input);
                if (nSelection ==1 ){  
                    System.out.println();
                    dayAvailability.DayAvailability();
                    System.out.println("You Have Exited Day Availability");
                    System.out.println();
                }
                else if (nSelection ==2 ){
                    System.out.println();                    
                    setAvailability.SetAvailability();
                    System.out.println("You Have Exited Set Availability");
                    System.out.println();
                }
                else if (nSelection ==3){
                    System.out.println();
                    fullAvailability.FullAvailability();
                    System.out.println("You Have Exited The Availability");
                    System.out.println();
                }
                System.out.println("Make Another Selection or Press \"10\" End Program");
                System.out.println();
            } catch (NumberFormatException ne) {
                System.out.println("Invalid Selection! Try Again.");
            }
        }

    }
    
}
